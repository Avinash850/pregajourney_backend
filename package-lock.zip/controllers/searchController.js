import pool from "../db.js";

/**
 * 🔍 Main Search API
 * Handles user searches for doctors, hospitals, and clinics by location + query.
 */
export const search = async (req, res) => {
  try {
    const { location, query } = req.query;

    if (!location || !query) {
      return res.status(400).json({ error: "Location and query are required" });
    }

    // 1️⃣ Try matching city first
    const [cityRows] = await pool.query(
      `SELECT id FROM cities WHERE name LIKE ? LIMIT 1`,
      [`%${location}%`]
    );

    let cityId = cityRows.length ? cityRows[0].id : null;

    // 2️⃣ If no city found, try matching area in address fields
    if (!cityId) {
      const [areaRows] = await pool.query(
        `
        SELECT DISTINCT c.id 
        FROM cities c
        JOIN doctors d ON d.city_id = c.id
        WHERE d.address LIKE ?
        UNION
        SELECT DISTINCT c.id
        FROM cities c
        JOIN hospitals h ON h.city_id = c.id
        WHERE h.address LIKE ?
        UNION
        SELECT DISTINCT c.id
        FROM cities c
        JOIN clinics cl ON cl.city_id = c.id
        WHERE cl.address LIKE ?
        LIMIT 1
      `,
        [`%${location}%`, `%${location}%`, `%${location}%`]
      );

      cityId = areaRows.length ? areaRows[0].id : null;
    }

    if (!cityId) {
      return res.json({ results: [] });
    }

    // 3️⃣ Doctor search
    const [doctors] = await pool.query(
      `SELECT 
          d.*
       FROM doctors d
       JOIN cities c ON d.city_id = c.id
       LEFT JOIN specializations s ON d.specialization_id = s.id
       WHERE c.id = ?
         AND (d.name LIKE ? OR s.name LIKE ? OR d.address LIKE ?)
       `,
      [cityId, `%${query}%`, `%${query}%`, `%${location}%`]
    );

    // 4️⃣ Hospital search
    const [hospitals] = await pool.query(
      `SELECT 
          h.id, 
          h.name, 
          'hospital' AS type,
          h.image,
          c.name AS city,
          h.address
       FROM hospitals h
       JOIN cities c ON h.city_id = c.id
       LEFT JOIN hospital_services hs ON h.id = hs.hospital_id
       LEFT JOIN services s ON hs.service_id = s.id
       LEFT JOIN hospital_procedures hp ON h.id = hp.hospital_id
       LEFT JOIN procedures p ON hp.procedure_id = p.id
       WHERE c.id = ?
         AND (h.name LIKE ? OR s.name LIKE ? OR p.name LIKE ? OR h.address LIKE ?)`,
      [cityId, `%${query}%`, `%${query}%`, `%${query}%`, `%${location}%`]
    );

    // 5️⃣ Clinic search
    const [clinics] = await pool.query(
      `SELECT 
          cl.id, 
          cl.name, 
          'clinic' AS type,
          cl.image,
          c.name AS city,
          cl.address
       FROM clinics cl
       JOIN cities c ON cl.city_id = c.id
       WHERE c.id = ?
         AND (cl.name LIKE ? OR cl.address LIKE ?)`,
      [cityId, `%${query}%`, `%${location}%`]
    );

    // 6️⃣ Merge + Sort
    const results = [...doctors, ...hospitals, ...clinics].sort((a, b) =>
      a.type.localeCompare(b.type)
    );

    return res.json({ results });
  } catch (error) {
    console.error("❌ Search error:", error);
    res.status(500).json({ error: "Server error" });
  }
};

/**
 * 💡 Suggestion API
 * Used for autocomplete dropdown while typing in the search bar.
 */
export const suggest = async (req, res) => {
  try {
    const { q } = req.query;

    // Check if q is null, an empty string, or the string "null"
    const isEmptyQuery = !q || q.trim().length === 0 || q.toLowerCase() === "null";

    // If no valid query is passed (empty, null or "null"), return all data without filtering
    const queries = [
      isEmptyQuery ? pool.query(`SELECT id, name, 'doctor' AS type FROM doctors LIMIT 5`) : pool.query(`SELECT id, name, 'doctor' AS type FROM doctors WHERE name LIKE ? LIMIT 5`, [`%${q}%`]),
      isEmptyQuery ? pool.query(`SELECT id, name, 'hospital' AS type FROM hospitals LIMIT 5`) : pool.query(`SELECT id, name, 'hospital' AS type FROM hospitals WHERE name LIKE ? LIMIT 5`, [`%${q}%`]),
      isEmptyQuery ? pool.query(`SELECT id, name, 'clinic' AS type FROM clinics LIMIT 5`) : pool.query(`SELECT id, name, 'clinic' AS type FROM clinics WHERE name LIKE ? LIMIT 5`, [`%${q}%`]),
      isEmptyQuery ? pool.query(`SELECT id, name, 'specialization' AS type FROM specializations LIMIT 5`) : pool.query(`SELECT id, name, 'specialization' AS type FROM specializations WHERE name LIKE ? LIMIT 5`, [`%${q}%`]),
      isEmptyQuery ? pool.query(`SELECT id, name, 'service' AS type FROM services LIMIT 5`) : pool.query(`SELECT id, name, 'service' AS type FROM services WHERE name LIKE ? LIMIT 5`, [`%${q}%`]),
      isEmptyQuery ? pool.query(`SELECT id, name, 'procedure' AS type FROM procedures LIMIT 5`) : pool.query(`SELECT id, name, 'procedure' AS type FROM procedures WHERE name LIKE ? LIMIT 5`, [`%${q}%`]),
      isEmptyQuery ? pool.query(`SELECT id, name, 'symptom' AS type FROM symptoms LIMIT 5`) : pool.query(`SELECT id, name, 'symptom' AS type FROM symptoms WHERE name LIKE ? LIMIT 5`, [`%${q}%`]),
      isEmptyQuery
        ? pool.query(`
            SELECT DISTINCT SUBSTRING_INDEX(address, ',', 1) AS name, 'area' AS type
            FROM (
              SELECT address FROM doctors
              UNION ALL
              SELECT address FROM hospitals
              UNION ALL
              SELECT address FROM clinics
            ) AS combined
            WHERE address IS NOT NULL
            LIMIT 5
          `)
        : pool.query(
            `
            SELECT DISTINCT SUBSTRING_INDEX(address, ',', 1) AS name, 'area' AS type
            FROM (
              SELECT address FROM doctors WHERE address LIKE ?
              UNION ALL
              SELECT address FROM hospitals WHERE address LIKE ?
              UNION ALL
              SELECT address FROM clinics WHERE address LIKE ?
            ) AS combined
            WHERE address IS NOT NULL
            LIMIT 5
          `,
            [`%${q}%`, `%${q}%`, `%${q}%`]
          ),
    ];

    // Execute all queries in parallel
    const [
      [doctors],
      [hospitals],
      [clinics],
      [specializations],
      [services],
      [procedures],
      [symptoms],
      [areas],
    ] = await Promise.all(queries);

    return res.json({
      doctors,
      hospitals,
      clinics,
      specializations,
      services,
      procedures,
      symptoms,
      areas,
    });
  } catch (error) {
    console.error("❌ Suggestion error:", error);
    res.status(500).json({ error: "Server error" });
  }
};



/**
 * 🔎 Detailed Search Data API
 * Fetch full record by type and id (doctor, hospital, clinic, etc.)
 * Includes city_name and specialization_name for doctors.
 */
export const getSearchDetails = async (req, res) => {
  console.log("sdjfljsdlfj==>", req.params)
  try {
    const { id, type } = req.query;

    if (!id || !type) {
      return res.status(400).json({ error: "id and type are required" });
    }

    // Allowed table mapping
    const tableMap = {
      doctor: "doctors",
      hospital: "hospitals",
      clinic: "clinics",
      specialization: "specializations",
      service: "services",
      procedure: "procedures",
      symptom: "symptoms",
    };

    const tableName = tableMap[type.toLowerCase()];

    if (!tableName) {
      return res.status(400).json({ error: "Invalid type" });
    }

    let rows;

    // 🩺 If it's a doctor, join with cities & specializations
    if (type.toLowerCase() === "doctor") {
      [rows] = await pool.query(
        `
        SELECT 
          d.*, 
          c.name AS city_name, 
          s.name AS specialization_name
        FROM doctors d
        LEFT JOIN cities c ON d.city_id = c.id
        LEFT JOIN specializations s ON d.specialization_id = s.id
        WHERE d.id = ?
        LIMIT 1
        `,
        [id]
      );
    } else {
      // 🏥 For other types, simple fetch
      [rows] = await pool.query(`SELECT * FROM ${tableName} WHERE id = ? LIMIT 1`, [id]);
    }

    if (rows.length === 0) {
      return res.status(404).json({ error: "No record found" });
    }

    return res.json({
      type,
      data: rows[0],
    });
  } catch (error) {
    console.error("❌ getSearchDetails error:", error);
    res.status(500).json({ error: "Server error" });
  }
};



