import pool from "../db.js";

export const suggestLocations = async (req, res) => {
  try {
    const { q } = req.query;

    // if (!q || q.trim().length < 2) {
    //   return res.json({ results: [] });
    // }

    const like = `%${q}%`;

    // 🧭 1️⃣ Fetch cities and states
    const [cities] = await pool.query(
      `SELECT 
          ci.id AS city_id,
          ci.name AS city,
          st.name AS state,
          co.name AS country
       FROM cities ci
       LEFT JOIN states st ON ci.state_id = st.id
       LEFT JOIN countries co ON st.country_id = co.id
       WHERE ci.name LIKE ?
          OR st.name LIKE ?
       ORDER BY ci.name ASC
       LIMIT 10`,
      [like, like]
    );

    // 🏙️ 2️⃣ Fetch areas directly from areas table (linked with cities)
    const [areas] = await pool.query(
      `SELECT 
          ar.id AS area_id,
          ar.name AS area,
          ci.id AS city_id,
          ci.name AS city,
          st.name AS state,
          co.name AS country
       FROM areas ar
       LEFT JOIN cities ci ON ar.city_id = ci.id
       LEFT JOIN states st ON ci.state_id = st.id
       LEFT JOIN countries co ON st.country_id = co.id
       WHERE ar.name LIKE ?
          OR ci.name LIKE ?
       ORDER BY ar.name ASC
       LIMIT 10`,
      [like, like]
    );

    // 🧩 3️⃣ Format both results for frontend
    const formattedCities = cities.map((r) => ({
      id: r.city_id,
      city_id: r.city_id,
      name: r.city,
      label: `${r.city}${r.state ? `, ${r.state}` : ""}`,
      type: "city",
      city: r.city,
      state: r.state || "",
      country: r.country || "",
    }));

    const formattedAreas = areas.map((a) => ({
      id: a.area_id,
      city_id: a.city_id,
      name: a.area,
      label: `${a.area}${a.city ? `, ${a.city}` : ""} (Area)`,
      type: "area",
      city: a.city || "",
      state: a.state || "",
      country: a.country || "",
    }));

    // 🧠 4️⃣ Merge and de-duplicate
    const allResults = [
      ...formattedAreas,
      ...formattedCities.filter(
        (city) => !formattedAreas.find((a) => a.city_id === city.city_id)
      ),
    ];

    return res.json({ results: allResults });
  } catch (error) {
    console.error("❌ Location suggestion error:", error);
    res.status(500).json({ error: "Server error" });
  }
};
